package com.mantasguajiras.backend.user.service;

import java.util.UUID;

import com.mantasguajiras.backend.user.dto.requests.ChangePasswordRequest;
import com.mantasguajiras.backend.user.dto.requests.UpdateUserRequest;
import com.mantasguajiras.backend.user.dto.requests.UserRequest;
import com.mantasguajiras.backend.user.dto.response.UserResponse;

public interface UserService {

    UserResponse create(UserRequest request);

    UserResponse findById(UUID id);

    UserResponse update(UUID id, UpdateUserRequest request);

    void changePassword(UUID id, ChangePasswordRequest request);

    void delete(UUID id);
}